// JavaScript from the web-app ( https://flatassembler.github.io/compiler.html
// ), minified to be runnable in less-performant JavaScript engines, such as
// Rhino and Duktape.
function finit() { asm("finit") }
function faddp() { asm("faddp") }
function fsubp() { asm("fsubp") }
function fmulp() { asm("fmulp") }
function fdivp() { asm("fdivp") }
function fsinp() { asm("fsin") }
function fcosp() { asm("fcos") }
function ftanp() { asm("fsincos"), fdivp() }
function fsqrt() { asm("fsqrt") }
function fatanp() { asm("fld1"), fatan2() }
function fatan2() { asm("fpatan") }
function fasinp() {
fstp(), fld(), asm("fld1"), fld(), fld(), fmulp(), fsubp(), fsqrt(), fdivp(),
fatanp()
}
function facosp() {
fstp(), asm("fldpi"), asm("fld1"), asm("fld1"), faddp(), fdivp(), fld(),
fasinp(), fsubp()
}
function flnp() {
asm("fld1"), asm("fxch"), asm("fyl2x"), asm("fldl2e"), fdivp()
}
function fexpp() {
asm("fldl2e"), fmulp(), asm("fld1"), asm("fscale"), asm("fxch"), asm("fld1"),
asm("fxch"), asm("fprem"), asm("f2xm1"), faddp(), fmulp()
}
function flogp() {
flnp(),
asm("mov dword [result]," +
(highlight ? '<span style="color:#007700">' : "") + "10" +
(highlight ? "</span>" : "")),
fild(), flnp(), fdivp()
}
function fpowp() { asm("fxch"), flnp(), fmulp(), fexpp() }
function fabsp() { asm("fabs") }
function fpmod() { asm("fxch"), asm("fprem"), asm("fxch"), fstp() }
function fcomip() {
  //Usporedi dva broja na vrhu stoga i postavi CPU-ove zastavice da oznacuju rezultat usporedbe.
  //"fcomip" postoji samo na i686 i novijim x86 procesorima, a mi ciljamo na i486.
  //https://www.vogons.org/viewtopic.php?p=1130626#p1130626
  asm("fcomp");
  asm(
    "push " +
      (highlight ? '<span style="color:#007777">' : "") +
      "ax" +
      (highlight ? "</span>" : "")
  );
  asm(
    "fstsw " +
      (highlight ? '<span style="color:#007777">' : "") +
      "ax" +
      (highlight ? "</span>" : "")
  );
  asm(
    "mov " +
      (highlight ? '<span style="color:#007777">' : "") +
      "al" +
      (highlight ? "</span>" : "") +
      "," +
      (highlight ? '<span style="color:#007777">' : "") +
      "ah" +
      (highlight ? "</span>" : "")
  );
  asm("lahf");
  asm(
    "and " +
      (highlight ? '<span style="color:#007777">' : "") +
      "ax" +
      (highlight ? "</span>" : "") +
      "," +
      (highlight ? '<span style="color:#007700">' : "") +
      "0xba45" +
      (highlight ? "</span>" : "") +
      " " +
      (highlight ? '<span style="color:#777777">' : "") +
      (syntax == "fasm" ? ";" : "#") +
      (highlight
        ? '<a href="https://www.vogons.org/viewtopic.php?p=1130827#p1130827">'
        : "") +
      "https://www.vogons.org/viewtopic.php?p=1130827#p1130827" +
      (highlight ? "</a></span>" : "")
  );
  asm(
    "or " +
      (highlight ? '<span style="color:#007777">' : "") +
      "ah" +
      (highlight ? "</span>" : "") +
      "," +
      (highlight ? '<span style="color:#007777">' : "") +
      "al" +
      (highlight ? "</span>" : "")
  );
  asm("sahf");
  asm(
    "pop " +
      (highlight ? '<span style="color:#007777">' : "") +
      "ax" +
      (highlight ? "</span>" : "")
  );
}
function fstp() {
if ("fasm" == syntax)
asm("fstp dword [result]");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("fstp dword ptr [result]")
}
}
function fld() {
if ("fasm" == syntax)
asm("fld dword [result]");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("fld dword ptr [result]")
}
}
function fild() {
if ("fasm" == syntax)
asm("fild dword [result]");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("fild dword ptr [result]")
}
}
function fistp() {
if ("fasm" == syntax)
asm("fistp dword [result]");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("fistp dword ptr [result]")
}
}
var syntax = "fasm", verboseMode = !1, varijable = new Object, alerted,
highlight = "undefined" != typeof window;
"undefined" == typeof window &&
(eval("var alert=function(x){throw String(x);};"),
eval("var prompt=function(x){return null;};")),
"undefined" != typeof ArrayBuffer && "undefined" != typeof Float32Array &&
(getIEEE754 =
function(e) {
var t = new Float32Array([ e ]).buffer, n = new Int32Array(t);
return (highlight ? '<span style="color:#007700">' : "") + "0x" +
n[0].toString(16) + (highlight ? "</span>" : "")
}),
Array.prototype.includes || (Array.prototype.includes = function(e) {
for (var t = 0; t < this.length; t++)
if (this[t] == e)
return !0;
return !1
});
var boolean = [ 0, 1, "<", "=", ">", "&", "|", "not(" ];
function Token(e) {
var t = new Object;
return t.operands = [], t.text = e, t.depth = 0, t.DFS = function() {
if (this.depth)
return this.depth;
if (this.operands.length)
for (var e = 0; e < this.operands.length; e++)
this.depth = Math.max(this.depth, this.operands[e].DFS() + 1);
else
this.depth = 1;
return this.depth
}, t.toLisp = function() {
if (this.name = this.text,
"(" != this.text.charAt(this.text.length - 1) &&
"[" != this.text.charAt(this.text.length - 1) ||
(this.name = this.text.slice(0, this.text.length - 1)),
this.operands.length) {
for (var e = "(" + this.name + " ", t = 0; t < this.operands.length; t++)
e += this.operands[t].toLisp() +
(t == this.operands.length - 1 ? "" : " ");
return (e += ")").replace(/\)\s\)/g, "))")
}
return this.text.replace(/\)\s\)/g, "))")
}, t.interpret = function() {
return alerted ? NaN
: "+" != this.text || this.operands.length
? "0" <= this.text.charAt(0) &&
this.text.charAt(0) <= "9"
? +this.text
: "?:" == this.text ? this.operands[0]
.interpret()
? this.operands[1]
.interpret()
: this.operands[2]
.interpret()
: "+" == this.text
? this.operands[0]
.interpret() +
this.operands[1]
.interpret()
: "-" == this.text
? this.operands[0]
.interpret() -
this.operands[1]
.interpret()
: "/" == this.text
? this.operands[0]
.interpret() /
this.operands[1]
.interpret()
: "\\" == this.text ? this.operands[1]
.interpret() /
this.operands[0]
.interpret()
: "*" == this.text ? this.operands[0]
.interpret() *
this.operands[1]
.interpret()
: "sin(" == this.text ? Math.sin(this.operands[0]
.interpret())
: "cos(" == this.text ? Math.cos(this.operands[0]
.interpret())
: "tan(" == this.text ? Math.tan(
this.operands
[0].interpret())
: "atan2(" == this.text ? Math.atan2(
this.operands
[0].interpret(),
this.operands
[1].interpret())
: "arctan(" ==
this.text
? Math.atan(
this.operands
[0].interpret())
: "ctg(" == this.text ? 1 / Math.tan(
this.operands[0]
.interpret())
: "arcctg(" == this.text ? Math.PI /
2 -
Math.atan(this
.operands
[0]
.interpret())
: "sqrt(" == this.text ? Math.sqrt(
this.operands
[0].interpret())
: "arcsin(" == this.text ? Math.asin(
this.operands
[0].interpret())
: "arccos(" == this.text ? Math.acos(
this.operands
[0].interpret())
: "ln(" == this.text ? Math.log(
this.operands
[0].interpret())
: "log(" ==
this.text
? Math.log(
this.operands
[0].interpret()) /
Math.log(
10)
: "exp(" ==
this.text
? Math.exp(
this.operands
[0].interpret())
: "pow(" ==
this.text
? Math.pow(this.operands
[0].interpret(),
this.operands
[1].interpret())
: "abs(" ==
this.text
? Math.abs(
this.operands
[0].interpret())
: "mod(" == this.text ? this.operands[0]
.interpret() %
this.operands[1]
.interpret()
: "=" == this.text
? +(
this.operands
[0].interpret() == this.operands[1]
.interpret())
: "<" == this.text
? +(this.operands
[0].interpret() <
this.operands
[1].interpret())
: ">" == this.text ? +(this.operands
[0].interpret() > this.operands
[1].interpret())
: "not(" ==
this.text
? (boolean.includes(
this.operands
[0]
.text) ||
alert(
"Interpreter warning: Casting a non-Boolean number into Boolean, may cause undefined behaviour."),
+!this.operands
[0]
.interpret())
: "&" == this.text
? (boolean.includes(
this.operands
[0].text) &&
boolean
.includes(
this.operands
[1].text) ||
alert(
"Interpreter warning: Casting a non-Boolean number into Boolean, may cause undefined behaviour."),
+(this.operands
[0].interpret() &&
this.operands
[1].interpret()))
: "|" == this.text
? (
boolean.includes(
this.operands
[0].text) &&
boolean
.includes(this.operands[1]
.text) ||
alert(
"Interpreter warning: Casting a non-Boolean number into Boolean, may cause undefined behaviour."),
+(this.operands
[0].interpret() ||
this.operands[1]
.interpret()))
: "(" == this.text
.charAt(
this.text
.length -
1)
? (alerted =
1,
alert(
"Interpreter error: Unrecognized function name '" +
this.text
.slice(
0,
this.text
.length -
1) +
"'."),
NaN)
: (
null == varijable[this.text] && ("undefined" != typeof window ? varijable
[this.text] = prompt("Enter the value of the variable '" + this.text + "'")
: alert(
"Interpreter error: Variable '" +
this.text +
"' is not declared.")),
+varijable[this.text])
: 1
}, t.commentedLispExpression = function() {
var e = "gas" == syntax ? "#" : ";";
highlight && (e = '<span style="color:#777777">' + e + "</span>");
for (var t = 'Pushing "' + this.toLisp() + '" to the FPU stack...', n = 0;
n < t.length; n++) {
var s = t.charAt(n);
highlight && ("&" == s && (s = "&amp;"), "<" == s && (s = "&lt;"),
">" == s && (s = "&gt;")),
e += highlight ? '<span style="color:#777777">' + s + "</span>" : s
}
return e
}, t.compile = function() {
if (" " != this.text) {
if ("+" != this.text || this.operands.length || (this.text = "1"),
"?:" == this.text) {
if (this.operands[2].compile(), this.operands[1].compile(),
this.operands[0].compile(),
verboseMode && asm(this.commentedLispExpression()), fistp(),
asm("xor eax,eax"), "fasm" == syntax)
asm("cmp dword [result],eax");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("cmp dword ptr [result],eax")
}
var e = (highlight ? '<span style="color:#777700">' : "") +
"firstOperandOfTheTernaryOperatorIsZeroLabel" +
Math.round(1e6 * Math.random()) + (highlight ? "</span>" : ""),
t = (highlight ? '<span style="color:#777700">' : "") +
"endOfTheTernaryOperatorLabel" +
Math.round(1e6 * Math.random()) + (highlight ? "</span>" : "");
if (asm("jz " + e), fstp(), "fasm" == syntax)
asm("mov eax, dword [result]");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("mov eax, dword ptr [result]")
}
if (fstp(), "fasm" == syntax)
asm("mov dword [result],eax");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("mov dword ptr [result],eax")
}
return fld(), asm("jmp " + t), asm(e + ":"), fstp(), void asm(t + ":")
}
var n, s = !1;
1 < this.operands.length &&
this.operands[0].DFS() < this.operands[1].DFS() &&
(s = !0, n = this.operands[0], this.operands[0] = this.operands[1],
this.operands[1] = n);
for (var a = 0; a < this.operands.length; a++)
this.operands[a].compile();
if (verboseMode && asm(this.commentedLispExpression()), s && asm("fxch"),
"0" <= this.text.charAt(0) && this.text.charAt(0) <= "9")
"function" != typeof getIEEE754
? asm("mov dword" + ("gas" == syntax ? " ptr" : "") + " [result]," +
(highlight ? '<span style="color:#007700">' : "") +
this.text + "f" + (highlight ? "</span>" : ""))
: asm("mov dword" + ("gas" == syntax ? " ptr" : "") + " [result]," +
getIEEE754(+this.text) +
(highlight ? ' <span style="color:#777777">' +
("gas" == syntax ? "#" : ";") +
"IEEE754 hex of " + this.text + "</span>"
: ("gas" == syntax ? " #" : " ;") +
"IEEE754 hex of " + this.text)),
fld();
else if ("+" == this.text)
faddp();
else if ("-" == this.text)
fsubp();
else if ("/" == this.text)
fdivp();
else if ("\\" == this.text)
asm("fxch"), fdivp();
else if ("*" == this.text)
fmulp();
else if ("sin(" == this.text)
fsinp();
else if ("cos(" == this.text)
fcosp();
else if ("tan(" == this.text)
ftanp();
else if ("ctg(" == this.text)
ftanp(),
asm("mov dword" + ("gas" == syntax ? " ptr" : "") + " [result]," +
(highlight ? '<span style="color:#007700">' : "") +
(getIEEE754 ? getIEEE754(-1) : "-1f") +
(highlight ? "</span>" : "")),
fld(), fpowp();
else if ("atan2(" == this.text)
fatan2();
else if ("arctan(" == this.text)
fatanp();
else if ("arcctg(" == this.text)
fatanp(), asm("fldpi"),
asm("mov dword [result]," +
(highlight ? '<span style="color:#007700">' : "") +
(getIEEE754 ? getIEEE754(2) : "2f") +
(highlight ? "</span>" : "")),
fld(), fdivp(), asm("fxch"), fsubp();
else if ("sqrt(" == this.text)
fsqrt();
else if ("arcsin(" == this.text)
fasinp();
else if ("arccos(" == this.text)
facosp();
else if ("ln(" == this.text)
flnp();
else if ("log(" == this.text)
flogp();
else if ("exp(" == this.text)
fexpp();
else if ("pow(" == this.text)
fpowp();
else if ("abs(" == this.text)
fabsp();
else if ("mod(" == this.text)
fpmod();
else if ("=" == this.text) {
e = (highlight ? '<span style="color:#777700">' : "") +
"operandsOfTheEqualityOperatorAreNotEqualLabel" +
Math.round(1e6 * Math.random()) + (highlight ? "</span>" : ""),
t = (highlight ? '<span style="color:#777700">' : "") +
"endOfTheEqualityOperatorLabel" + Math.round(1e6 * Math.random()) +
(highlight ? "</span>" : "");
fcomip(), fstp(), asm("jne " + e), asm("fld1"), asm("jmp " + t),
asm(e + ":"), asm("fldz"), asm(t + ":")
} else if ("<" == this.text) {
e = (highlight ? '<span style="color:#777700">' : "") +
"secondOperandOfTheComparisonIsSmallerOrEqualLabel" +
Math.round(1e6 * Math.random()) + (highlight ? "</span>" : ""),
t = (highlight ? '<span style="color:#777700">' : "") +
"endOfTheLessThanComparisonLabel" +
Math.round(1e6 * Math.random()) + (highlight ? "</span>" : "");
fcomip(), fstp(), asm("jna " + e), asm("fld1"), asm("jmp " + t),
asm(e + ":"), asm("fldz"), asm(t + ":")
} else if (">" == this.text) {
e = (highlight ? '<span style="color:#777700">' : "") +
"secondOperandOfTheComparisonIsGreaterOrEqualLabel" +
Math.round(1e6 * Math.random()) + (highlight ? "</span>" : ""),
t = (highlight ? '<span style="color:#777700">' : "") +
"endOfTheGreaterThanComparisonLabel" +
Math.round(1e6 * Math.random()) + (highlight ? "</span>" : "");
fcomip(), fstp(), asm("jnb " + e), asm("fld1"), asm("jmp " + t),
asm(e + ":"), asm("fldz"), asm(t + ":")
} else if ("not(" == this.text)
boolean.includes(this.operands[0].text) ||
alert(
"Compiler warning: Casting a non-Boolean number into Boolean, may cause undefined behaviour."),
asm("fld1"), asm("fxch"), fsubp();
else if ("&" == this.text) {
if (boolean.includes(this.operands[0].text) &&
boolean.includes(this.operands[1].text) ||
alert(
"Compiler warning: Casting a non-Boolean number into Boolean, may cause undefined behaviour."),
fistp(), "fasm" == syntax)
asm("mov eax,dword [result]");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("mov eax,dword ptr [result]")
}
if (fistp(), "fasm" == syntax)
asm("and dword [result],eax");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("and dword ptr [result],eax")
}
fild()
} else if ("|" == this.text) {
if (boolean.includes(this.operands[0].text) &&
boolean.includes(this.operands[1].text) ||
alert(
"Compiler warning: Casting a non-Boolean number into Boolean, may cause undefined behaviour."),
fistp(), "fasm" == syntax)
asm("mov eax,dword [result]");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("mov eax,dword ptr [result]")
}
if (fistp(), "fasm" == syntax)
asm("or dword [result],eax");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("or dword ptr [result],eax")
}
fild()
} else if ("(" == this.text.charAt(this.text.length - 1) ||
"[" == this.text.charAt(this.text.length - 1))
if ("undefined" != typeof window)
alerted = 1,
alert("Compiler error: Unrecognized function name '" +
this.text.slice(0, this.text.length - 1) + "'."),
asm((highlight ? '<span style="color:#777777">' : "") +
";Here the linker should insert the code for calling the function '" +
this.text.slice(0, this.text.length - 1) + "'!" +
(highlight ? "</span>" : ""));
else {
if (fistp(), "fasm" == syntax)
asm("mov ebx, dword [result]");
else {
if ("gas" != syntax)
throw "Invalid syntax name!";
asm("mov ebx,dword ptr [result]")
}
asm("fld dword" + ("gas" == syntax ? " ptr" : "") + " [" +
this.text.substr(0, this.text.length - 1) + "+4*ebx]" +
("fasm" == syntax
? " ;In case the program is supposed to be 16-bit, simply replace 'ebx' with 'bx'. In case it's 64-bit, replace the 'mov' in the last directive with 'movsx' and 'ebx' with 'rbx' in both this and the last directive."
: ""))
}
else {
if (mnemonike.includes(this.text) || registri.includes(this.text))
return alert(
"Compiler error: Can't use the word \"" + this.text +
'" as a variable name because it is a reserved keyword in x86 assembly.'),
void (alerted = 1);
asm("fld dword " + ("gas" == syntax ? "ptr " : "") +
(highlight ? '<span style="color:#770000">' : "") + "[" +
this.text + "]" + (highlight ? "</span>" : ""))
}
}
}, t
}
function tokenizeArth(e) {
if (alerted)
return [];
var t = [ "" ];
String.prototype.charAtIndex ||
(String.prototype.charAtIndex = function(e) { return this.charAt(e) }),
e = (e = e.replace(/\)\(/g, ")*(")).replace(/;.*$/, " ");
for (var n = !1, s = 0; s < e.length; s++)
"0" <= e.charAtIndex(s) && e.charAtIndex(s) <= "9" ||
"." == e.charAtIndex(s) ||
"A" <= e.charAtIndex(s) && e.charAtIndex(s) <= "Z" ||
"a" <= e.charAtIndex(s) && e.charAtIndex(s) <= "z" ||
"_" == e.charAtIndex(s) ||
"sin" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"cos" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"tan" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"arcsin" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"arccos" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"arctan" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"pow" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"log" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"ln" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"exp" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"sqrt" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"atan2" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"abs" == t[t.length - 1] && "(" == e.charAtIndex(s) ||
"not" == t[t.length - 1] && "(" == e.charAtIndex(s) || n
? (t[t.length - 1] = t[t.length - 1] + e.charAtIndex(s),
'"' != e.charAtIndex(s) && "'" != e.charAtIndex(s) || (n = !n))
: (t.push(e.charAtIndex(s)), t.push(""),
'"' != e.charAtIndex(s) && "'" != e.charAtIndex(s) ||
(n = !n, t.pop())),
"(" != t[t.length - 1].charAtIndex(t[t.length - 1].length - 1) &&
"[" !=
t[t.length - 1].charAtIndex(t[t.length - 1].length - 1) ||
n || t.push("");
for (s = 0; s < t.length; s++)
t[s].length && " " != t[s] || (t.splice(s, 1), s--);
for (s = 1; s < t.length; s++)
if ("-" == t[s] &&
("+" == t[s - 1] || "-" == t[s - 1] || "*" == t[s - 1] ||
"/" == t[s - 1] || ">" == t[s - 1] || "<" == t[s - 1] ||
"=" == t[s - 1] || ":" == t[s - 1] || "?" == t[s - 1])) {
if (t.splice(s, 0, "("), s + 2 >= t.length)
return alert(
"Tokenizer error: Unable to assign the type to the operator '-' (whether it's unary or binary)."),
alerted = 1, t;
if ("(" != t[s + 2].charAt(t[s + 2].length - 1))
t.splice(s + 3, 0, ")");
else {
var a = s + 3, o = 1;
do {
if (a >= t.length)
return alert(
"Tokenizer error: Unable to assign the type to the operator '-' (whether it's unary or binary)."),
alerted = 1, t;
"(" == t[a].charAt(t[a].length - 1)
? o++
: ")" == t[a].charAt(t[a].length - 1) && o--,
a++
} while (o);
t.splice(a, 0, ")")
}
}
for (s = 0; s < t.length; s++)
if ("a" <= t[s].charAt(0) && t[s].charAt(0) <= "z" &&
("(" == t[s + 1] && "(" != t[s].charAt(t[s].length - 1) ||
"[" == t[s + 1]))
t[s] += t[s + 1], t.splice(s + 1, 1);
else if ("0" <= t[s].charAt(0) && t[s].charAt(0) <= "9")
for (var r = 0, a = 0; a < t[s].length; a++) {
if (r && "." == t[s].charAt(a) ||
(t[s].charAt(a) < "0" || "9" < t[s].charAt(a)) &&
"." != t[s].charAt(a))
return alert("Tokenizer error: Can't assign the type to the token '" +
t[s] + "'."),
alerted = 1, t;
r || "." != t[s].charAt(a) || (r = 1)
}
else if ('"' == t[s].charAt(0) || "'" == t[s].charAt(0)) {
if (3 != t[s].length || t[s].charAt(0) != t[s].charAt(2) ||
"'" != t[s].charAt(0))
return alerted = 1,
alert(
"Tokenizer error: The token " + t[s] +
" appears to be a string, which this program doesn't support."),
t;
t[s] = t[s].charCodeAt(1).toString()
}
return t
}
function parseArth(e) {
if (alerted)
return Token(" ");
if (!e.length)
return alert(
"Parser error: No expression between the parentheses ('()' is not a valid syntax)."),
alerted = 1, Token(" ");
for (var t = 0; t < e.length; t++)
null == e[t].text && (e[t] = Token(e[t]));
for (t = 0; t < e.length; t++)
if ("pow(" != e[t].text && "atan2(" != e[t].text && "mod(" != e[t].text ||
e[t].operands.length)
if ("(" != e[t].text.charAt(e[t].text.length - 1) &&
"[" != e[t].text.charAt(e[t].text.length - 1) ||
e[t].operands.length || "pow(" == e[t].text ||
"atan2(" == e[t].text || "mod(" == e[t].text || "(" == e[t].text) {
if ("(" == e[t].text) {
for (n = 1, s = 0; n;) {
if (t + ++s >= e.length)
return alerted = 1,
alert("Parser error: Mismatched parentheses."), e[0];
")" == e[t + s].text
? n--
: "(" == e[t + s].text.charAt(e[t + s].text.length - 1) && n++
}
for (a = [], o = 1; o < s; o++)
a.push(e[t + o].text);
e[t] = parseArth(a), e.splice(t + 1, s)
}
} else {
for (var n = 1, s = 0; n;) {
if (t + ++s >= e.length)
return alerted = 1,
alert(
"Parser error: Expected a ')' to mark the end of the argument of a unary function."),
e[0];
")" == e[t + s].text || "]" == e[t + s].text
? n--
: "(" != e[t + s].text.charAt(e[t + s].text.length - 1) &&
"[" != e[t + s].text.charAt(e[t + s].text.length - 1) ||
e[t + s].operands.length || n++
}
for (a = [], o = 1; o < s; o++)
a.push(e[t + o].text);
e[t].operands.push(parseArth(a)), e.splice(t + 1, s),
"arctan(" == e[t].text || "arcsin(" == e[t].text ||
"arccos(" == e[t].text || "arcctg(" == e[t].text
? ((a = Token("*")).operands.push(Token(180 / Math.PI + "")),
a.operands.push(e[t]), e[t] = a)
: "sin(" != e[t].text && "cos(" != e[t].text &&
"tan(" != e[t].text && "ctg(" != e[t].text ||
((a = Token("/")).operands.push(e[t].operands[0]),
a.operands.push(Token(180 / Math.PI + "")),
e[t].operands[0] = a)
}
else {
for (var n = 1, s = 0; n;) {
if (t + ++s >= e.length)
return alerted = 1,
alert(
"Parser error: Expected a ',' to divide the arguments of a binary function."),
e[0];
"," == e[t + s].text
? n--
: "pow(" != e[t + s].text && "atan2(" != e[t + s].text &&
"mod(" != e[t + s].text ||
n++
}
for (var a = [], o = 1; o < s; o++)
a.push(e[t + o].text);
e[t].operands.push(parseArth(a));
var o = 0;
for (n = 1; n;) {
if (t + s + ++o >= e.length)
return alerted = 1,
alert(
"Parser error: Expected a ')' to mark the end of the second argument of a binary function."),
e[0];
")" == e[t + s + o].text
? n--
: "(" == e[t + s + o].text.charAt(e[t + s + o].text.length - 1) &&
n++
}
a = [];
for (var r = 1; r < o; r++)
a.push(e[t + s + r].text);
e[t].operands.push(parseArth(a)), e.splice(t + 1, s + o),
"atan2(" == e[t].text &&
((a = Token("*")).operands.push(Token(180 / Math.PI + "")),
a.operands.push(e[t]), e[t] = a)
}
if (alerted)
return e[0];
if (("-" == e[0].text || "+" == e[0].text) && !e[0].operands.length) {
if (1 == e.length)
return alerted = 1,
alert("Parser error: The binary operator '" + e[0].text +
"' has less than two operands."),
e[0];
e[0].operands.push(Token("0")), e[0].operands.push(e[1]), e.splice(1, 1)
}
for (t = 0; t < e.length; t++)
if (("*" == e[t].text || "/" == e[t].text || "\\" == e[t].text) &&
!e[t].operands.length) {
if (e.length - 1 == t || !t)
return alerted = 1,
alert("Parser error: The binary operator '" + e[t].text +
"' has less than two operands."),
e[0];
e[t].operands.push(e[t - 1]), e[t].operands.push(e[t + 1]),
e.splice(t - 1, 1), e.splice(t, 1), t--
}
for (t = 0; t < e.length; t++)
if (("+" == e[t].text || "-" == e[t].text) && !e[t].operands.length) {
if (e.length - 1 == t || !t)
return alerted = 1,
alert("Parser error: The binary operator '" + e[t].text +
"' has less than two operands."),
e[0];
e[t].operands.push(e[t - 1]), e[t].operands.push(e[t + 1]),
e.splice(t - 1, 1), e.splice(t, 1), t--
}
for (t = 0; t < e.length; t++)
if (("=" == e[t].text || "<" == e[t].text || ">" == e[t].text) &&
!e[t].operands.length) {
if (e.length - 1 == t || !t)
return alerted = 1,
alert("Parser error: The binary operator '" + e[t].text +
"' has less than two operands."),
e[0];
e[t].operands.push(e[t - 1]), e[t].operands.push(e[t + 1]),
e.splice(t - 1, 1), e.splice(t, 1), t--
}
for (t = 0; t < e.length; t++)
if ("&" == e[t].text && !e[t].operands.length) {
if (e.length - 1 == t || !t)
return alerted = 1,
alert("Parser error: The binary operator '" + e[t].text +
"' has less than two operands."),
e[0];
e[t].operands.push(e[t - 1]), e[t].operands.push(e[t + 1]),
e.splice(t - 1, 1), e.splice(t, 1), t--
}
for (t = 0; t < e.length; t++)
if ("|" == e[t].text && !e[t].operands.length) {
if (e.length - 1 == t || !t)
return alerted = 1,
alert("Parser error: The binary operator '" + e[t].text +
"' has less than two operands."),
e[0];
e[t].operands.push(e[t - 1]), e[t].operands.push(e[t + 1]),
e.splice(t - 1, 1), e.splice(t, 1), t--
}
for (t = 0; t < e.length; t++)
if ("?" == e[t].text) {
if (e.length - 1 == t || !t)
return alerted = 1,
alert(
"Parser error: The ternary operator '?:' has less than three operands!"),
e[0];
e[t].operands.push(e[t - 1]), e[t].text = "?:";
s = 1, n = 1;
do {
if (t + s >= e.length)
return alerted = 1,
alert(
"Parser error: There is a '?' without its corresponding ':'."),
e[0];
"?" == e[t + s].text && n++, ":" == e[t + s].text && n--, s++
} while (n);
for (var i = new Array, o = t + 1; o < t + s - 1; o++)
i.push(e[o]);
e[t].operands.push(parseArth(i));
for (var l = new Array, o = t + s; o < e.length; o++)
l.push(e[o]);
e[t].operands.push(parseArth(l)), e = [ e[t] ]
}
return 1 < e.length &&
(alerted = 1,
alert("Parser error: Unexpected token '" + e[1].text + "'.")),
checkAST(e[0]), e[0]
}
function checkAST(e) {
("*" == e.text || "-" == e.text || "/" == e.text || "=" == e.text ||
"<" == e.text || ">" == e.text || "&" == e.text || "|" == e.text) &&
e.operands.length < 2 && !alerted &&
(alerted = 1, alert("Parser error: Unexpected token '" + e.text + "'."));
for (var t = 0; t < e.operands.length; t++)
checkAST(e.operands[t])
}
eval("0=='+'") && (boolean[0] = "0", boolean[1] = "1");
var mnemonike =
[
"mov",    "fxch",    "fabs",   "fild",  "f2xm1", "fprem", "fld1",
"fscale", "fldl2e",  "fyl2x",  "fldpi", "fstp",  "fld",   "fpatan",
"fsqrt",  "fsincos", "fcos",   "fsin",  "fdivp", "fmulp", "fsubp",
"faddp",  "finit",   "fcomip", "jne",   "jmp",   "fldz",  "jna",
"jnb",    "fistp",   "and",    "or",    "xor",   "jz",    "cmp"
],
registri = [ "eax", "st0", "st1" ], assembler = "";
function compile() {
try {
if (syntax = document.getElementById("FASM").checked ? "fasm" : "gas",
verboseMode = document.getElementById("verbose").checked,
"gas" == syntax && "function" != typeof getIEEE754)
return alert(
"Generating GAS-compatible code requires a modern JavaScript interpreter which supports ArrayBuffer!"),
void (alerted = 1);
alerted = 0, document.getElementById("diagramSpan").style.display = "none",
interpreter.innerHTML = "null";
for (var e = "[", t = tokenizeArth(document.getElementById("input").value),
n = 0;
n < t.length; n++)
n < t.length - 1 ? e += "'" + t[n] + "', " : e += "'" + t[n] + "']";
if (/\]$/.test(e) || (e += "]"),
document.getElementById("tokenized").innerHTML = e,
document.getElementById("LISP").innerHTML =
parseArth(tokenizeArth(document.getElementById("input").value))
.toLisp(),
assembler = document.getElementById("assembly").innerHTML = "",
"gas" == syntax && asm(".intel_syntax noprefix"), verboseMode) {
var s = "Initializing FPU...";
s = "gas" == syntax ? "#" + s : ";" + s;
for (var a = "", n = 0; n < s.length; n++)
a += '<span style="color:#777777">' + s.charAt(n) + "</span>";
asm(a)
}
if (finit(),
parseArth(tokenizeArth(document.getElementById("input").value))
.compile(),
verboseMode) {
s = 'Moving "st0" (top of the FPU stack) into "result"...';
s = "gas" == syntax ? "#" + s : ";" + s;
for (a = "", n = 0; n < s.length; n++)
a += '<span style="color:#777777">' + s.charAt(n) + "</span>";
asm(a)
}
fstp(), "gas" == syntax && asm(".att_syntax"),
highlight && syntaxHighlighting(),
document.getElementById("assembly").innerHTML = assembler
} catch (e) {
alert(
'Internal compiler error!\nThe message generated by your JavaScript interpreter is: "' +
e.name + ": " + e.message +
'".\nPlease e-mail me (Teo Samarzija, you can get to my e-mail address by opening the menu by clicking the icon in the top left corner of the popup or by minimizing the popup and right-clicking the icon you get at the bottom of the window) with the instructions on how to reproduce that error (for example, which arithmetic expression you entered). But don\'t do that if you are one of those people who are using Internet Explorer, Android Stock Browser or, even worse, Netscape, to browse the modern web. I\'ve wasted enough of my time already to make this web-app work in those browsers. What works in other browsers immediately doesn\'t work in them even after hours of tweaking (because they are not open-source and, to improve them, you need to ask the companies who make them "Mother, may I?", to which they usually respond "No, you are not good enough at programming. Government, protect us from this thief!"). JavaScript is not the best programming language in the world, and the JavaScript interpreters that don\'t abide the new standards make it even worse.')
}
}
function syntaxHighlighting() {
for (var i = 0; i < mnemonike.length; i++)
assembler = assembler.replace(eval("/\\s" + mnemonike[i] + "\\s/g"),
'<span style="color:#000077">' +
mnemonike[i] + "</span> ");
assembler = assembler.replace(/\[result\]/g,
'<span style="color:#770000">[result]</span>'),
assembler =
assembler.replace(/dword/g, '<span style="color:#770077">dword</span>');
for (var i = 0; i < registri.length; i++)
assembler = assembler.replace(eval("/" + registri[i] + "/g"),
'<span style="color:#007777">' + registri[i] +
"</span>");
assembler = assembler.replace(/\,/g, '<span style="color:#333333">,</span>'),
assembler =
assembler.replace(/:\s/g, '<span style="color:#333333">:</span> '),
assembler = assembler.replace(
".intel_syntax", '<span style="color:#773300">.intel_syntax</span>'),
assembler = assembler.replace(
".att_syntax", '<span style="color:#773300">.att_syntax</span>'),
assembler = assembler.replace("noprefix",
'<span style="color:#337700">noprefix</span>'),
assembler =
assembler.replace(/ptr/g, '<span style="color:#337700">ptr</span>')
}
function interpret() {
try {
alerted = 0, document.getElementById("diagramSpan").style.display = "none",
varijable = new Object;
for (var e = "[", t = tokenizeArth(document.getElementById("input").value),
n = 0;
n < t.length; n++)
n < t.length - 1 ? e += "'" + t[n] + "', " : e += "'" + t[n] + "']";
document.getElementById("tokenized").innerHTML = e,
document.getElementById("LISP").innerHTML =
parseArth(tokenizeArth(document.getElementById("input").value))
.toLisp(),
document.getElementById("assembly").innerHTML = "",
document.getElementById("interpreter").innerHTML =
parseArth(tokenizeArth(document.getElementById("input").value))
.interpret()
} catch (e) {
alert(
'Internal compiler error!\nThe message generated by your JavaScript interpreter is: "' +
e.name + ": " + e.message +
'".\nPlease e-mail me (Teo Samarzija, you can get to my e-mail address by opening the menu by clicking the icon in the top left corner of the popup or by minimizing the popup and right-clicking the icon you get at the bottom of the window) with the instructions on how to reproduce that error (for example, which arithmetic expression you entered). But don\'t do that if you are one of those people who are using Internet Explorer, Android Stock Browser or, even worse, Netscape, to browse the modern web. I\'ve wasted enough of my time already to make this web-app work in those browsers. What works in other browsers immediately doesn\'t work in them even after hours of tweaking (because they are not open-source and, to improve them, you need to ask the companies who make them "Mother, may I?", to which they usually respond "No, you are not good enough at programming. Government, protect us from this thief!"). JavaScript is not the best programming language in the world, and the JavaScript interpreters that don\'t abide the new standards make it even worse.')
}
}
function asm(e) {
assembler += ("undefined" != typeof window ? "\n" : "") + e +
("undefined" != typeof window ? "\n<br/>" : "\n")
}
var maxX = 0, maxY = 0, minY = 0, sessionID;
function showAST() {
if (maxX = maxY = minX = 0, !document.createElementNS)
return alert(
"Diagram error: Can't access the SVG elements from JavaScript. You appear to be using a browser that doesn't support that. If you are using Internet Explorer 11, make sure it isn't running in the compatibility mode."),
void (alerted = 1);
alerted = 0, document.getElementById("diagramSpan").style.display = "block",
document.getElementById("assembly").innerHTML = "",
interpreter.innerHTML = "null";
for (var e = "[", t = tokenizeArth(document.getElementById("input").value),
n = 0;
n < t.length; n++)
n < t.length - 1 ? e += "'" + t[n] + "', " : e += "'" + t[n] + "']";
document.getElementById("tokenized").innerHTML = e;
var s = parseArth(tokenizeArth(document.getElementById("input").value));
for (document.getElementById("LISP").innerHTML = s.toLisp();
document.getElementById("diagram").childNodes.length;)
document.getElementById("diagram").removeChild(
document.getElementById("diagram").firstChild);
if (5 < s.DFS())
return alert(
"Diagram error: The AST is too deep to be shown using a simple diagram. The maximal depth is set to be 5."),
void (alerted = 1);
var a = -1 != s.toLisp().indexOf("?:");
draw(s, 0, 0, 200 * Math.pow(a ? 3 : 2, s.DFS() - 2), 0, a),
document.getElementById("diagram").style.width = maxX - minX + 200,
document.getElementById("diagram").style.height = maxY + 100;
for (n = 0; n < document.getElementById("diagram").childNodes.length; n++)
document.getElementById("diagram").childNodes[n].getAttribute("x") &&
document.getElementById("diagram").childNodes[n].setAttribute(
"x",
document.getElementById("diagram").childNodes[n].getAttribute("x") -
minX),
document.getElementById("diagram").childNodes[n].getAttribute("x1") &&
document.getElementById("diagram").childNodes[n].setAttribute(
"x1",
document.getElementById("diagram").childNodes[n].getAttribute(
"x1") -
minX),
document.getElementById("diagram").childNodes[n].getAttribute("x2") &&
document.getElementById("diagram").childNodes[n].setAttribute(
"x2",
document.getElementById("diagram").childNodes[n].getAttribute(
"x2") -
minX);
document.getElementById("diagramSpan").scrollLeft =
document.getElementById("node0").getAttribute("x") -
document.getElementById("diagramSpan").clientWidth / 2 + 75
}
function draw(e, t, n, s, a, o) {
maxX < t && (maxX = t), t < minX && (minX = t), maxY < n && (maxY = n);
var r = "http://www.w3.org/2000/svg", i = document.createElementNS(r, "rect");
i.setAttribute("x", t), i.setAttribute("y", n), i.setAttribute("width", 150),
i.setAttribute("height", 50),
i.style.fill = "#FFAAAA", i.setAttribute("id", "node" + a),
1 == e.DFS() && (i.style.fill = "#AAFFAA"),
1 == e.operands.length && (i.style.fill = "#AAAAFF"),
document.getElementById("diagram").appendChild(i);
var l, d = document.createElementNS(r, "text");
if (d.appendChild(document.createTextNode(e.text)),
d.setAttribute("x", t + 75 - 4 * e.text.length),
d.setAttribute("y", n + 20), d.style.fill = "black",
d.setAttribute("font-family", "monospace"),
d.setAttribute("font-size", 14),
document.getElementById("diagram").appendChild(d),
1 != e.operands.length || t)
if (1 == e.operands.length && t < 0) {
draw(e.operands[0], t + (o ? 3 : 1) / (o ? 3 : 2) * s, n + 100,
s / (o ? 3 : 2), a + 1, o),
(l = document.createElementNS(r, "line")).setAttribute("x1", t + 75),
l.setAttribute("y1", n + 50),
l.setAttribute("x2", t + (o ? 3 : 1) / (o ? 3 : 2) * s + 75),
l.setAttribute("y2", n + 100), l.setAttribute("stroke-width", 2),
l.setAttribute("stroke", "black"),
document.getElementById("diagram").appendChild(l)
} else if (1 == e.operands.length && 0 < t) {
draw(e.operands[0], t - (o ? 3 : 1) / (o ? 3 : 2) * s, n + 100,
s / (o ? 3 : 2), a + 1, o),
(l = document.createElementNS(r, "line")).setAttribute("x1", t + 75),
l.setAttribute("y1", n + 50),
l.setAttribute("x2", t - (o ? 3 : 1) / (o ? 3 : 2) * s + 75),
l.setAttribute("y2", n + 100), l.setAttribute("stroke-width", 2),
l.setAttribute("stroke", "black"),
document.getElementById("diagram").appendChild(l)
} else if (2 == e.operands.length && o && t < 0)
for (var h = 1; h < e.operands.length + 1; h++) {
draw(e.operands[h - 1], t + (h - (o ? 3 : 1) / (o ? 3 : 2)) * s,
n + 100, s / (o ? 3 : 2), a + 1, o),
(l = document.createElementNS(r, "line"))
.setAttribute("x1", t + 75),
l.setAttribute("y1", n + 50),
l.setAttribute("x2", t + (h - (o ? 3 : 1) / (o ? 3 : 2)) * s + 75),
l.setAttribute("y2", n + 100), l.setAttribute("stroke-width", 2),
l.setAttribute("stroke", "black"),
document.getElementById("diagram").appendChild(l)
}
else if (2 == e.operands.length && o && !t)
for (h = 0; h < e.operands.length + 1; h++) {
1 != h &&
(draw(e.operands[0 == h ? h : 1],
t + (h - (o ? 3 : 1) / (o ? 3 : 2)) * s, n + 100,
s / (o ? 3 : 2), a + 1, o),
(l = document.createElementNS(r, "line"))
.setAttribute("x1", t + 75),
l.setAttribute("y1", n + 50),
l.setAttribute("x2", t + (h - (o ? 3 : 1) / (o ? 3 : 2)) * s + 75),
l.setAttribute("y2", n + 100), l.setAttribute("stroke-width", 2),
l.setAttribute("stroke", "black"),
document.getElementById("diagram").appendChild(l))
}
else
for (h = 0; h < e.operands.length; h++) {
draw(e.operands[h], t + (h - (o ? 3 : 1) / (o ? 3 : 2)) * s, n + 100,
s / (o ? 3 : 2), a + 1, o),
(l = document.createElementNS(r, "line"))
.setAttribute("x1", t + 75),
l.setAttribute("y1", n + 50),
l.setAttribute("x2", t + (h - (o ? 3 : 1) / (o ? 3 : 2)) * s + 75),
l.setAttribute("y2", n + 100), l.setAttribute("stroke-width", 2),
l.setAttribute("stroke", "black"),
document.getElementById("diagram").appendChild(l)
}
else
draw(e.operands[0], t, n + 100, s / (o ? 3 : 2), a + 1, o),
(l = document.createElementNS(r, "line")).setAttribute("x1", t + 75),
l.setAttribute("y1", n + 50), l.setAttribute("x2", t + 75),
l.setAttribute("y2", n + 100), l.setAttribute("stroke-width", 2),
l.setAttribute("stroke", "black"),
document.getElementById("diagram").appendChild(l)
}
function downloadAJAX() {
try {
if (sessionID = Math.floor(100 * Math.random()), compile(), alerted)
return;
document.getElementById("AJAXmessage").style.display = "inline";
for (var e = [], t = tokenizeArth(document.getElementById("input").value),
n = 0;
n < t.length; n++)
("a" <= t[n].charAt(0) && t[n].charAt(0) <= "z" ||
"A" <= t[n].charAt(0) && t[n].charAt(0) <= "Z") &&
"(" != t[n].charAt(t[n].length - 1) && !e.includes(t[n]) &&
e.push(t[n]);
e.sort();
for (var s = "[", n = 0; n < e.length; n++)
s += '"' + e[n] + '",';
s = s.substring(0, s.length - 1) + "]";
var a, o = document.getElementById("assembly").innerText;
if (!o)
return alerted = 1,
alert(
"Emitter error: Your browser doesn't appear to support the JavaScript 'innerText' directive. Can't send the assembly code to the server. Please use either Internet Explorer or some modern browser."),
void (document.getElementById("AJAXmessage").style.display =
"none");
/\n\n/.test(o) && (o = o.replace(/\n\n*/g, "\n")),
/\n$/.test(o) || (o += "\n"),
(a = window.XMLHttpRequest ? new XMLHttpRequest
: new ActiveXObject("Microsoft.XMLHTTP"))
.open("POST", "setDownload.php", !0),
a.onreadystatechange =
function() {
4 == this.readyState &&
(document.getElementById("AJAXmessage").style.display = "none",
200 == this.status
? window.download && window.download instanceof Function
? window.download(
"http://flatassembler.000webhostapp.com/download" +
sessionID + ".asm")
: window.location.assign(
"http://flatassembler.000webhostapp.com/download" +
sessionID + ".asm")
: this.status - 200 &&
(alerted = 1,
alert("Emitter error: Can't connect to the server.")))
},
a.setRequestHeader("Content-type", "application/x-www-form-urlencoded"),
a.send("varijable=" + s + "&kod=" + o + "&sessionID=" + sessionID),
window.XMLHttpRequest || !1 === navigator.onLine ||
setTimeout(function() {
var e = new ActiveXObject("Microsoft.XMLHTTP");
e.open("HEAD", "download" + sessionID + ".asm", !1), e.send(null),
document.getElementById("AJAXmessage")
.style.display = "none",
alerted || (200 == e.status
? window.location.assign(
"http://flatassembler.000webhostapp.com/download" +
sessionID + ".asm")
: alert("Emitter error: Can't connect to the server."))
}, 3e3)
} catch (e) {
alerted = 1,
alert("Emitter error: " + e.message +
" (this is the message generated by the browser)."),
document.getElementById("AJAXmessage").style.display = "none"
}
}
function sendMail(e) {
var t;
"Tomasz" == e ? t =
[
6,  2,  36, 28, 1, 42, 17, 21, 23, 50, 54, 9,  21, 17,
19, 35, 17, 22, 8, 16, 60, 0,  6,  75, 28, 53, 17
]
: "Teo" == e && (t = [
27, 0,  36, 75, 1,  49, 8, 21, 23, 8,  57, 15,
21, 37, 21, 61, 29, 4,  9, 92, 51, 10, 25
]);
var n, s = t[0];
t[0] = t[2], t[2] = s, s = t[17], t[17] = t[16], t[16] = s,
"Teo" == e ? n = 554 : "Tomasz" == e && (n = 603);
for (
var a = prompt(
"Spambot protection problem: What is the name of the fictional character who had a spell casted on him so that he couldn't grow up, and he had to fight against the pirates? His nickname is 'Pan'.",
"His name without 'Pan'."),
o = [], r = 0;
r < t.length; r++)
o.push(t[r] ^ a.charCodeAt(r % a.length));
for (var i = 0, r = 0; r < o.length; r++)
i = (128 * i + o[r]) % 907;
if (i == n) {
for (var l = "", r = 0; r < o.length; r++)
l += String.fromCharCode(o[r]);
window.location.assign("mailto:" + l)
} else
alert("Unfortunately, you didn't give the expected answer.")
}
function resetBackEnd() {
if (sessionID = Math.floor(100 * Math.random()), !window.XMLHttpRequest)
return alerted = 1,
void alert(
"Emitter error: Your browser doesn't appear to support the JavaScript 'XMLHttpRequest' object. Connecting to the server using the ActiveX controls is not secure.");
var e = prompt("Enter password (known by Teo Samarzija):");
document.getElementById("AJAXmessage").style.display = "inline";
var a = new XMLHttpRequest;
a.password = e, a.open("POST", "oneTimeKey.php", !0),
a.setRequestHeader("Content-type", "application/x-www-form-urlencoded"),
a.send("sessionId=" + sessionID), a.onreadystatechange = function() {
if (4 == this.readyState) {
for (var e = this.responseText - sessionID - 256 * sessionID, t = "[",
n = this.password, s = 0;
s < n.length; s++)
t += (n.charCodeAt(s) ^ (s % 2 ? e % 256 : e / 256)) +
(s < n.length - 1 ? "," : "]");
new XMLHttpRequest;
a.open("POST", "deleteDownloads.php", !0),
a.setRequestHeader("Content-type",
"application/x-www-form-urlencoded"),
a.send("password=" + t + "&sessionId=" + sessionID),
a.onreadystatechange = function() {
4 == this.readyState &&
alert(
'Emitter message: The server apparently responded with "' +
this.responseText +
(this.status - 200 ? " (Error " + this.status + ")" : "") +
'".'),
document.getElementById("AJAXmessage").style.display = "none"
}
}
}
}
"undefined" != typeof window &&
(window.onresize =
function() {
var e = !1;
(document.getElementById("zatvori").offsetWidth < 18 ||
"21px" == document.getElementById("zatvori").style.width) &&
"none" != document.getElementById("zatvori").style.display &&
(e = !0);
try {
document.getElementById("content").style.width =
document.body.clientWidth - 30 + "px",
document.getElementById("content").style.height =
document.body.clientHeight - 49 + "px",
document.getElementById("titleBar").style.width =
document.body.clientWidth - 30 - 60 + "px",
document.getElementById("smanji").style.left =
document.body.clientWidth - 30 - 60 + 21 - 15 * e + "px",
document.getElementById("povecaj").style.left =
document.body.clientWidth - 30 - 60 + 42 - 15 * e + "px",
document.getElementById("zatvori").style.left =
document.body.clientWidth - 30 - 60 + 63 - 15 * e + "px"
} catch (e) {
window.onresize = function() {},
alert(
"Driver warning: You appear to be using a browser in which the JavaScript directive 'document.body.clientWidth' isn't correctly implemented.The layout will probably break if you resize the window.\nIf possible, please use a browser that correctly implements that directive, such as Internet Explorer 6, Internet Explorer 9 or Internet Explorer 11 (but not Internet Explorer 7, Internet Explorer 8 or Internet Explorer 10).\nOr, better yet, don't use Internet Explorer. Microsoft doesn't include Internet Explorer in Windows because it wants you to use it as a regular browser. It's there because:\n1. When you have just installed a new operating system, you need to use it to download a proper browser from the Internet.\n2. If some incompetent programmer tries to enable his C or C++ program to display web-pages by linking it against the DLL of Trident (the legacy web-engine used in Internet Explorer), that his program doesn't crash immediately.\n3. If you are forced to use a computer with 512MB of RAM and 1Ghz Celeron processor running Windows 7 to do something on-line.\n4. If some program uses the Active-X controls (a legacy technology used in Internet Explorer to simulate some features of modern JavaScript) to install itself.\n5. Some ethernet programs that haven't been updated for decades, used in some government agencies, might work slightly better in Internet Explorer than in proper browsers if run on modern computers.\nSo, Internet Explorer has its uses, but exploring the Internet isn't one of them."),
document.getElementById("content").style.width = "100%",
document.getElementById("content").style.height = "100%",
document.getElementById("titleBar").style.width = "100%",
document.getElementById("smanji").style.right = "50px",
document.getElementById("povecaj").style.right = "29px",
document.getElementById("zatvori").style.right = "8px"
}
e && (document.getElementById("smanji").style.width = "21px",
document.getElementById("povecaj").style.width = "21px",
document.getElementById("zatvori").style.width = "21px");
var t = document.getElementsByTagName("mark");
document.getElementsByTagName("nav")[0].style.height =
30 * t.length + "px",
document.getElementsByTagName("nav")[0].style.top = "27px",
document.getElementsByTagName("nav")[0].style.left = "13px";
for (var n = 0; n < t.length; n++)
t[n].style.display = "block", t[n].style.position = "absolute",
t[n].style.top = 30 * n + "px", t[n].style.left = "0px",
t[n].style.zIndex = 101, t[n].style.width = "250px",
t[n].style.background = "#EEEEEE",
t[n].style.borderStyle = "none none solid none",
t[n].style.borderWidth = "1px", t[n].style.padding = "5px",
t[n].style.fontFamily = "Arial", t[n].onmouseout = function() {
this.style.background = "#EEEEEE", this.style.color = "black"
}, t[n].onmouseenter = function() {
this.style.background = "#0000AA", this.style.color = "white"
}, window.XMLHttpRequest || (t[n].style.height = "30px");
document.getElementById("about")
.onclick =
function() {
alert(
"This web-app was made by Teo Samarzija. It is not connected to Tomasz Grysztar, the creator of FlatAssembler, in any way.\nIt is open-source. You can see most of its source just by clicking 'View Source' in your browser. Its back-end is so simple that probably anyone who knows basic PHP could make it, so you don't need source for that (of course, the same is not true for the PHP interpreter, the Apache web server and the 000webhost hosting service that power this website).\nIts purpose is to popularize Assembly language programming, and also to impress his computer science professor, and perhaps his future employer.")
},
document.getElementById("download").onclick =
function() {
window.open("https://www.flatassembler.net/download.php")
},
document.getElementById("exit").onclick = function() { history.back() },
document.getElementById("mailMe").onclick =
function() { sendMail("Teo") },
document.getElementById("mailTomasz").onclick =
function() { sendMail("Tomasz") },
document.getElementById("backEndReset").onclick =
function() { resetBackEnd() },
10 < document.getElementById("zatvori").style.left.substring(
0, document.getElementById("zatvori").style.left.length - 2) -
document.getElementById("content").style.width.substring(
0, document.getElementById("content")
.style.width.length -
2) &&
(document.getElementById("content").style.width =
document.getElementById("zatvori").style.left.substring(
0,
document.getElementById("zatvori").style.left.length -
2) -
3 + "px");
var s = document.getElementById("shareIt");
s.style.position = "absolute", s.style.fontFamily = "Arial",
s.style.color = "white",
s.style.paddingLeft = s.style.paddingRight = "8px",
s.style.left = document.body.clientWidth / 2 - s.offsetWidth / 2,
s.style.top = document.body.clientHeight / 2 - s.offsetHeight / 2,
s.style.textAlign = "center",
document.getElementById("smanji").onclick =
function() {
document.getElementById("content").style.display = "none",
document.getElementById("titleBar").style.display = "none",
document.getElementById("smanji").style.display = "none",
document.getElementById("povecaj").style.display = "none",
document.getElementById("zatvori").style.display = "none",
document.getElementById("favicon").style.display = "none",
document.getElementById("ikona").style.display = "block",
document.getElementById("opis").style.backgroundColor =
"transparent",
document.getElementsByTagName("nav")[0].style.display = "none",
document.getElementById("ikona").style.left =
document.body.clientWidth / 2 -
document.getElementById("ikona").offsetWidth / 2,
document.getElementById("ikona").style.top = "auto",
document.getElementById("ikona").style.bottom = "8px"
},
/(M|m)obile/.test(navigator.userAgent)
? document.getElementById("ikona").onclick =
function() {
document.getElementById("content").style.display = "block",
document.getElementById("titleBar").style.display = "block",
document.getElementById("smanji").style.display = "block",
document.getElementById("povecaj").style.display = "block",
document.getElementById("zatvori").style.display = "block",
document.getElementById("favicon").style.display = "block",
document.getElementById("ikona").style.display = "none"
}
: (document.getElementById("ikona").ondblclick =
function() {
document.getElementById("content")
.style.display = "block",
document.getElementById("titleBar").style.display = "block",
document.getElementById("smanji").style.display = "block",
document.getElementById("povecaj").style.display = "block",
document.getElementById("zatvori").style.display = "block",
document.getElementById("favicon").style.display = "block",
document.getElementById("ikona").style.display = "none",
document.getElementsByTagName("nav")[0].style.display = "none",
document.getElementsByTagName("nav")[0].style.top = "27px",
document.getElementsByTagName("nav")[0].style.left = "13px"
},
document.getElementById("ikona").onclick =
function() {
document.getElementById("opis").style.backgroundColor =
"blue"
},
document.getElementById("ikona").onmousedown =
function(e) {
e && 2 == e.button ||
window.event && 2 == window.event.button ||
dragInit(this)
},
document.getElementById("ikona").oncontextmenu =
function(e) {
return document.getElementsByTagName("nav")[0]
.style.display = "block",
this.offsetTop + +document.getElementsByTagName("nav")[0].clientHeight <
document.body.clientHeight
? document.getElementsByTagName("nav")[0]
.style.top = this.offsetTop + 5 + "px"
: document.getElementsByTagName("nav")[0]
.style.top =
this.offsetTop + 50 -
document.getElementsByTagName("nav")[0]
.clientHeight +
"px",
document.getElementsByTagName("nav")[0].style.left =
this.offsetLeft + 5 + "px",
e && e.stopPropagation && e.stopPropagation(), !1
}),
document.getElementById("povecaj").onclick = function() {
window.onresize = function() {},
document.getElementById("titleBar").style.display = "none",
document.getElementById("smanji").style.display = "none",
document.getElementById("povecaj").style.display = "none",
document.getElementById("zatvori").style.display = "none",
document.getElementById("favicon").style.display = "none",
document.getElementById("content").style.background = "#FFFFFF",
document.getElementById("content").style.left = "0px",
document.getElementById("content").style.top = "0px",
document.getElementById("content").style.width = "100%",
document.getElementById("content").style.height = "100%",
document.getElementById("content").style.borderStyle = "none",
document.getElementById("content").style.padding = "0px",
document.getElementById("content").style.position = "static",
document.getElementById("showMenu").style.display = "block",
document.getElementById("showMenu").onclick =
function() {
"none" == document.getElementsByTagName("nav")[0].style.display
? document.getElementsByTagName("nav")[0].style.display =
"block"
: document.getElementsByTagName("nav")[0].style.display =
"none"
},
document.getElementById("shareIt").style.display = "none",
document.body.style.background = "transparent",
document.getElementById("content").onclick = function() {}
}
}),
"undefined" != typeof window && onresize(),
"undefined" != typeof navigator && /(M|m)obile/.test(navigator.userAgent) &&
(document.getElementById("content").onclick = function() {
document.getElementsByTagName("nav")[0].style.display = "none"
});
var isFirefox = !1, selected, x_pos = 0, y_pos = 0, x_elem = 0, y_elem = 0;
function dragInit(e) {
x_elem = x_pos - (selected = e).offsetLeft,
y_elem = y_pos - selected.offsetTop
}
function moveElement(e) {
window.event || (isFirefox = !0, window.event = new Object),
isFirefox &&
(window.event.clientX = e.clientX, window.event.clientY = e.clientY),
x_pos = window.event.clientX, y_pos = window.event.clientY,
"block" == document.getElementsByTagName("nav")[0].style.display &&
(x_pos - document.getElementsByTagName("nav")[0].offsetLeft < 0 ||
x_pos - document.getElementsByTagName("nav")[0].offsetLeft >
document.getElementsByTagName("nav")[0].clientWidth ||
y_pos - document.getElementsByTagName("nav")[0].offsetTop < -20 ||
y_pos - document.getElementsByTagName("nav")[0].offsetTop >
document.getElementsByTagName("nav")[0].clientHeight) &&
(document.getElementsByTagName("nav")[0].style.display = "none"),
selected && (selected.style.left = x_pos - x_elem + "px",
selected.style.top = y_pos - y_elem + "px")
}
function destroy(e) {
window.event || (isFirefox = !0, window.event = new Object),
isFirefox &&
(window.event.clientX = e.clientX, window.event.clientY = e.clientY),
(window.event.clientX <
+document.getElementById("ikona").style.left.substring(
0, document.getElementById("ikona").style.left.length - 2) ||
window.event.clientX >
+document.getElementById("ikona").style.left.substring(
0, document.getElementById("ikona").style.left.length - 2) +
document.getElementById("ikona").offsetWidth ||
window.event.clientY <
+document.getElementById("ikona").style.top.substring(
0, document.getElementById("ikona").style.top.length - 2) ||
window.event.clientY >
+document.getElementById("ikona").style.top.substring(
0, document.getElementById("ikona").style.top.length - 2) +
document.getElementById("ikona").offsetHeight) &&
(document.getElementById("opis").style.backgroundColor =
"transparent"),
selected = null
}
"undefined" != typeof window &&
(document.onmousemove = moveElement, document.onmouseup = destroy),
"undefined" == typeof document || document.getElementsByClassName ||
(document.getElementsByClassName = function(str) {
for (var niz = document.getElementsByTagName("*"), ret = [], i = 0;
i < niz.length; i++)
eval("/(\\s|^)" + str + "(\\s|$)/").test(niz[i].className) &&
ret.push(niz[i]);
return ret
});
